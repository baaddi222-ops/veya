-- VEYA 0.1 — Migration 0004
-- RLS policies implementing the approved 0.1 privacy decision:
-- OWNER-ONLY access to both tables. No public/anonymous read policy exists
-- in 0.1 — see docs/SECURITY_DECISIONS.md and the architecture review §2
-- for the full reasoning (no follows/blocking/reporting/moderation exist
-- yet, and no 0.1 feature needs public reads, so starting maximally
-- restrictive and adding a public-read policy additively in 0.2 is the
-- safer migration path).
--
-- Deliberately using small helper functions rather than inlining
-- `auth.uid() = id` directly in every policy: when 0.2+ introduces
-- follows/blocking/age-category-aware visibility, the change happens in
-- ONE function, not by rewriting every policy that references these
-- tables. See docs/adr/0007-owner-only-rls-default-in-0.1.md.

create or replace function public.is_owner(row_owner_id uuid)
returns boolean
language sql
stable
set search_path = public, pg_temp
as $$
  select auth.uid() = row_owner_id;
$$;

alter table public.profiles enable row level security;
alter table public.user_privacy_settings enable row level security;

-- ============ profiles ============

-- SELECT: owner only. No anonymous or cross-user read in 0.1.
drop policy if exists profiles_select_owner_only on public.profiles;
create policy profiles_select_owner_only
  on public.profiles
  for select
  to authenticated
  using (public.is_owner(id));

-- INSERT: none via client. Rows are created ONLY by the
-- handle_new_user() SECURITY DEFINER trigger (migration 0003).
-- No insert policy is created here on purpose — with RLS enabled and no
-- INSERT policy, all client-side inserts are denied by default.

-- UPDATE: owner only, and only while the account is active — a suspended
-- or soft-deleted account cannot be edited by its own (possibly
-- compromised, or intentionally frozen) session.
drop policy if exists profiles_update_owner_only on public.profiles;
create policy profiles_update_owner_only
  on public.profiles
  for update
  to authenticated
  using (public.is_owner(id) and account_status = 'active')
  with check (public.is_owner(id));

-- DELETE: none via client. Account deletion is a future orchestrated
-- server-side process (see docs/adr and architecture review §6), not a
-- bare client DELETE. No delete policy is created — denied by default.

-- ============ user_privacy_settings ============

drop policy if exists privacy_settings_select_owner_only on public.user_privacy_settings;
create policy privacy_settings_select_owner_only
  on public.user_privacy_settings
  for select
  to authenticated
  using (public.is_owner(user_id));

drop policy if exists privacy_settings_update_owner_only on public.user_privacy_settings;
create policy privacy_settings_update_owner_only
  on public.user_privacy_settings
  for update
  to authenticated
  using (public.is_owner(user_id))
  with check (public.is_owner(user_id));

-- INSERT/DELETE: none via client — same trigger-owns-lifecycle reasoning
-- as profiles. No policy created — denied by default.
