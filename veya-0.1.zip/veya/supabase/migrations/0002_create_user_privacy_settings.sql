-- VEYA 0.1 — Migration 0002
-- Creates `user_privacy_settings`, kept separate from `profiles` on purpose
-- (see docs/adr/0006-separate-privacy-settings-table.md).
--
-- NOTE on is_private_account (per approved architecture review, §2):
-- this column is STORED BUT INERT in 0.1. RLS makes every profile/privacy
-- row owner-only in 0.1 regardless of this flag's value — there is no
-- public-read policy yet. The column exists now so 0.2 (which introduces
-- follows/blocking/reporting alongside the first public-read policy) does
-- not need a schema migration to add it, only a policy change.

create table if not exists public.user_privacy_settings (
  user_id uuid primary key references public.profiles (id) on delete cascade,
  is_private_account boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

comment on column public.user_privacy_settings.is_private_account is
  'Stored but INERT in VEYA 0.1 — no RLS policy currently reads this value. '
  'All profile/privacy data is owner-only in 0.1 regardless. This becomes '
  'meaningful in 0.2 when the first public-read policy is introduced '
  'alongside follows/blocking/reporting.';

drop trigger if exists user_privacy_settings_set_updated_at on public.user_privacy_settings;
create trigger user_privacy_settings_set_updated_at
  before update on public.user_privacy_settings
  for each row
  execute function public.set_updated_at();
