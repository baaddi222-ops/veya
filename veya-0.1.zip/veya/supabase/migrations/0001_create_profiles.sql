-- VEYA 0.1 — Migration 0001
-- Creates the `profiles` table: identity-only data for an authenticated user.
-- See docs/DATABASE_SCHEMA.md and docs/adr/0006-separate-privacy-settings-table.md
-- for why policy/privacy data is NOT in this table.

create table if not exists public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  username text not null,
  display_name text,
  avatar_url text,
  bio text,
  account_status text not null default 'active',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  constraint profiles_username_length check (char_length(username) between 3 and 24),
  constraint profiles_username_format check (username ~ '^[a-z0-9_]+$'),
  constraint profiles_bio_length check (bio is null or char_length(bio) <= 280),
  constraint profiles_account_status_valid
    check (account_status in ('active', 'suspended', 'deleted'))
);

create unique index if not exists profiles_username_unique_idx
  on public.profiles (username);

comment on table public.profiles is
  'VEYA 0.1: identity-only profile data. Policy/compliance data (age, country, '
  'guardian links) is intentionally NOT stored here — see ADR-0006 and '
  'docs/adr for why that is kept in separate future tables.';

-- Keep updated_at accurate on every row change.
-- Deliberately SECURITY INVOKER (the default): this trigger only touches a
-- row the caller already has UPDATE rights to via RLS, so it needs no
-- elevated privilege. SECURITY DEFINER is reserved narrowly for the signup
-- trigger in 0003, where elevation is actually required — see
-- docs/adr/0009-profile-creation-trigger-design.md.
create or replace function public.set_updated_at()
returns trigger
language plpgsql
set search_path = public, pg_temp
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

drop trigger if exists profiles_set_updated_at on public.profiles;
create trigger profiles_set_updated_at
  before update on public.profiles
  for each row
  execute function public.set_updated_at();
