-- VEYA 0.1-E -- Migration 0007
-- Real gap found during the 0.1-E audit: `bio` has a 280-char CHECK
-- constraint (established in migration 0001), but `display_name` had NO
-- length constraint at all -- an inconsistency with the project's own
-- established pattern that the database is the final security boundary
-- (0.1-C's authorization model), not merely the Flutter form's max-length.
-- Without this, a client bypassing the Flutter app (any direct REST call
-- with a valid session) could set an arbitrarily long display_name.
--
-- 50 characters chosen as a conventional display-name limit. char_length()
-- is Unicode-codepoint-aware (matches the existing bio constraint's
-- behavior, confirmed live with a mixed Arabic/Latin/emoji test string),
-- not byte-length, so this does not penalize legitimate multi-byte-UTF8
-- names.

alter table public.profiles
  add constraint profiles_display_name_length
  check (display_name is null or char_length(display_name) <= 50);
