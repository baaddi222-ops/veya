-- VEYA 0.1 — Migration 0003
-- Signup trigger: on every new auth.users row, atomically creates exactly
-- one `profiles` row and one `user_privacy_settings` row.
--
-- Design rationale, security properties, and failure-mode reasoning are
-- documented in full in docs/adr/0009-profile-creation-trigger-design.md.
-- Summary of the mandatory security properties implemented below:
--
--   1. SECURITY DEFINER — required because the auth.users insert context is
--      not an authenticated RLS session with insert rights on public tables.
--   2. `set search_path = public, pg_temp` — pinned explicitly to prevent
--      search_path hijacking, a known SECURITY DEFINER privilege-escalation
--      vector in Postgres.
--   3. Every object referenced is schema-qualified (`public.profiles`, not
--      `profiles`) as a second, independent layer of the same protection.
--   4. Minimal scope — this function does exactly two inserts and nothing
--      else. No dynamic SQL, no broader grants than required.
--   5. Placeholder username is derived from the new user's UUID, which is
--      guaranteed unique — this removes "email-derived username collides"
--      as a realistic trigger-failure cause. The user is expected to choose
--      a real username in a post-signup "complete your profile" step
--      (application-level flow, not built into this trigger).
--   6. Both inserts happen in the SAME trigger, inside the SAME transaction
--      as the auth.users insert. If either insert fails, the whole
--      transaction rolls back — including the auth.users row — so it is
--      architecturally impossible for an authenticated user to exist
--      without exactly one profile and one privacy-settings row.

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  placeholder_username text;
begin
  placeholder_username := 'user_' || substr(new.id::text, 1, 8);

  insert into public.profiles (id, username)
  values (new.id, placeholder_username);

  insert into public.user_privacy_settings (user_id)
  values (new.id);

  return new;
end;
$$;

comment on function public.handle_new_user() is
  'SECURITY DEFINER by necessity (see migration header comment and '
  'docs/adr/0009). search_path is pinned and all objects are schema-'
  'qualified to prevent search_path hijacking. Scope is limited to exactly '
  'two inserts tied to NEW.id — no broader privilege is exercised.';

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row
  execute function public.handle_new_user();
