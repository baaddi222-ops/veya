-- VEYA 0.1-C — Migration 0006
-- Privilege hardening for two REAL findings from the 0.1-C security audit
-- (both confirmed live against veya-dev, invisible to RLS-only review):
--
--   FINDING 1 (confirmed live): an authenticated owner could UPDATE their
--   own `created_at` and `account_status` directly, since the UPDATE RLS
--   policy's WITH CHECK only verifies row ownership (is_owner(id)), not
--   which columns changed. Neither field should be client-settable —
--   created_at is an identity/audit field, account_status is a
--   system/future-moderation-owned field, not something a user should be
--   able to self-assign (e.g. self-suspending or un-suspending).
--
--   FINDING 2 (confirmed live via information_schema.role_table_grants):
--   `anon` held table-level INSERT/UPDATE/DELETE grants on both tables
--   (Supabase's broad-by-default convention). RLS already blocked anon
--   completely (0 policies for anon = deny-all), but leaving the
--   table-level grant in place meant RLS enablement was the ONLY thing
--   standing between anon and full table access. Removing the grant
--   closes this one layer earlier (defense in depth).
--
-- Fix: (a) revoke anon's blanket grants entirely on both tables; (b) for
-- authenticated, drop the blanket INSERT/UPDATE/DELETE grant and instead
-- grant UPDATE only on the specific columns an owner may actually change.
-- Row creation stays exclusively the trigger's job (handle_new_user runs
-- SECURITY DEFINER as the function owner, so it does NOT depend on
-- `authenticated` holding its own INSERT grant to succeed — confirmed
-- live: a regression test signup after this migration still worked) —
-- see docs/adr/0010-column-level-update-privileges.md.

-- ---- anon: remove all table-level access ----
revoke insert, update, delete, truncate, references, trigger, select
  on public.profiles from anon;
revoke insert, update, delete, truncate, references, trigger, select
  on public.user_privacy_settings from anon;

-- ---- authenticated: remove privileges no policy ever uses ----
revoke insert, delete, truncate, references, trigger, update
  on public.profiles from authenticated;
revoke insert, delete, truncate, references, trigger, update
  on public.user_privacy_settings from authenticated;

-- authenticated keeps SELECT (a table-level grant is a prerequisite before
-- RLS is even evaluated) and regains UPDATE only on the columns an owner
-- may change. id, created_at, updated_at, account_status are deliberately
-- excluded from profiles — none of these should be directly client-settable.
grant select on public.profiles to authenticated;
grant select on public.user_privacy_settings to authenticated;

grant update (username, display_name, avatar_url, bio)
  on public.profiles to authenticated;

grant update (is_private_account)
  on public.user_privacy_settings to authenticated;
