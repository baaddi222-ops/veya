-- VEYA 0.1 — Migration 0005
-- Hardening fix for a REAL finding from Supabase's security advisor
-- (get_advisors, run live against the veya-dev project — NOT caught by
-- static code review alone): handle_new_user(), though SECURITY DEFINER
-- and intended ONLY to run as the auth.users trigger, was callable
-- directly by anon/authenticated via PostgREST's automatic RPC exposure
-- (/rest/v1/rpc/handle_new_user). This revokes that unintended surface.
--
-- Least-privilege principle (architecture review §9): a function should
-- only be callable by whoever actually needs to call it. Nothing except
-- the trigger mechanism itself needs to call handle_new_user().

revoke execute on function public.handle_new_user() from anon;
revoke execute on function public.handle_new_user() from authenticated;
revoke execute on function public.handle_new_user() from public;

-- Same hardening applied consistently to is_owner() and set_updated_at(),
-- neither of which needs to be directly RPC-callable either, even though
-- both are lower-risk (is_owner only reads auth.uid(); set_updated_at only
-- fires as a row trigger).
revoke execute on function public.is_owner(uuid) from anon;
revoke execute on function public.is_owner(uuid) from public;

revoke execute on function public.set_updated_at() from anon;
revoke execute on function public.set_updated_at() from authenticated;
revoke execute on function public.set_updated_at() from public;
