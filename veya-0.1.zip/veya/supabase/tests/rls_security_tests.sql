-- VEYA 0.1 / 0.1-C — RLS / security adversarial tests
--
-- STATUS as of 0.1-C: ALL scenarios below (TEST 1-15) were run live against
-- the veya-dev Supabase project during the 0.1-B and 0.1-C audits. Results
-- are transcribed in docs/RELEASE_STATUS.md. This file remains the
-- reference specification -- re-run it in full after any future schema,
-- RLS, or grant change, since these are exactly the kind of change most
-- likely to silently regress.
--
-- How to run: apply all migrations 0001-0006 to a test project, then run
-- each block via `psql` (or the Supabase SQL editor) using
-- `set local role authenticated;` + `set local request.jwt.claim.sub = '<uuid>';`
-- for an authenticated session, `set local role anon;` for anonymous, and
-- `reset role;` for an elevated/service context (test setup only).

-- ---------------------------------------------------------------------
-- Setup: real signed-up test users on a disposable test project, never
-- production, always deleted after the run. Ids substituted as
-- :user_a_id / :user_b_id below.
-- ---------------------------------------------------------------------

-- TEST 1 -- Owner can read their own profile.
-- Expected / observed: 1 row returned. EXECUTED -- PASS.

-- TEST 2 -- User A cannot read User B's profile.
-- Expected / observed: 0 rows returned. EXECUTED -- PASS.

-- TEST 3 -- Anonymous (unauthenticated) caller cannot read ANY profile.
-- Expected / observed (post-0.1-C): permission denied at the GRANT layer
-- (was: 0 rows via RLS pre-0.1-C -- anon's table grant was revoked in
-- migration 0006, so the denial now happens one layer earlier). EXECUTED -- PASS.

-- TEST 4 -- User A cannot update User B's profile (on an allowed column).
-- Expected / observed: 0 rows affected. EXECUTED -- PASS.

-- TEST 5 -- User A cannot directly INSERT a profiles row (bypassing the trigger).
-- Expected / observed: permission denied for table profiles (42501),
-- now at the GRANT layer post-0.1-C (authenticated's INSERT grant was
-- revoked in migration 0006 -- the trigger doesn't need it, since it runs
-- SECURITY DEFINER). EXECUTED -- PASS.

-- TEST 6 -- User A cannot DELETE any profile, including their own.
-- Expected / observed: permission denied for table profiles (42501),
-- now at the GRANT layer post-0.1-C. EXECUTED -- PASS.

-- TEST 7 -- user_privacy_settings: User A cannot read User B's row.
-- Expected / observed: 0 rows returned. EXECUTED -- PASS.

-- TEST 8 -- Suspended account cannot update its own profile.
-- Expected / observed: 0 rows affected. EXECUTED -- PASS.

-- TEST 9 -- Signup trigger creates exactly one profiles row and one
-- user_privacy_settings row for a genuinely new auth.users insert, with a
-- unique, well-formed placeholder username matching '^user_[0-9a-f]{8}$'.
-- Expected / observed: confirmed on 5 separate real signups across the
-- 0.1-B and 0.1-C audits (including one with deliberately hostile
-- raw_user_meta_data -- see TEST 13). EXECUTED -- PASS.

-- TEST 10 -- Duplicate username on UPDATE is rejected cleanly.
-- Expected / observed: unique_violation (23505). EXECUTED -- PASS.

-- ====================== Added in 0.1-C ======================

-- TEST 11 -- OWNERSHIP FIELD PROTECTION (the real finding this audit made):
-- an owner must NOT be able to change created_at or account_status via a
-- normal UPDATE, even on their own row.
-- Pre-0.1-C fix: FAILED -- both fields were silently changeable.
-- Post-0.1-C fix (migration 0006, column-level grants): permission denied
-- for table profiles (42501). EXECUTED -- PASS (after fix).

-- TEST 12 -- Direct RPC call to handle_new_user() by an authenticated user
-- (bypassing the intended trigger-only invocation path).
-- Expected / observed: permission denied for function handle_new_user
-- (42501), after migration 0005 revoked EXECUTE from anon/authenticated.
-- EXECUTED -- PASS.

-- TEST 13 -- Trigger immunity to hostile/malicious auth.users metadata:
-- signup with raw_user_meta_data containing a SQL-injection-shaped string
-- and a large unicode payload.
-- Expected / observed: profiles table unaffected/still exists; the
-- resulting profile row has null display_name/bio and a normal
-- placeholder username -- the trigger never reads raw_user_meta_data at
-- all, so hostile metadata has zero effect by construction. EXECUTED -- PASS.

-- TEST 14 -- Username constraint matrix: empty string, 25-character string,
-- uppercase, and a SQL-injection-shaped string, each attempted via UPDATE.
-- Expected / observed: each rejected by the appropriate CHECK constraint
-- (profiles_username_format or profiles_username_length); a valid
-- lowercase/underscore username in the allowed length range succeeds.
-- EXECUTED -- PASS (all 4 rejections + 1 valid acceptance confirmed).

-- TEST 15 -- Concurrent username collision.
-- NOT independently executed via true parallel connections -- this
-- execute_sql tool runs one statement stream at a time, so genuine
-- concurrent-transaction testing isn't possible in this environment.
-- Documented instead of faked: the protection mechanism is a Postgres
-- unique b-tree index (profiles_username_unique_idx), which is atomic by
-- construction at the storage-engine level regardless of concurrency --
-- this is precisely why the architecture never relied on an application-
-- level "SELECT first, then INSERT/UPDATE" check (section 7 of the 0.1-C spec).
-- STATICALLY VERIFIED (index definition + Postgres's documented
-- uniqueness-enforcement guarantees), not independently EXECUTED under
-- real concurrency.
