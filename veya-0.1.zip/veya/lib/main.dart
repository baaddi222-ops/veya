import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'app.dart';
import 'core/config/env.dart';
import 'core/config/secure_session_storage.dart';
import 'core/logging/app_logger.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Fails fast and loudly rather than silently starting with no backend
  // configured. See core/config/env.dart.
  Env.assertConfigured();

  await Supabase.initialize(
    url: Env.supabaseUrl,
    anonKey: Env.supabaseAnonKey, // anon/public key ONLY — never service-role.
    // Persists the session (including tokens) via encrypted platform
    // secure storage rather than supabase_flutter's plain-SharedPreferences
    // default — see core/config/secure_session_storage.dart and
    // docs/adr/0012-encrypted-session-storage.md.
    authOptions: FlutterAuthClientOptions(
      localStorage: SecureSessionStorage(),
    ),
  );

  AppLogger.info('VEYA starting — env=${Env.appEnv}');

  runApp(const ProviderScope(child: VeyaApp()));
}
