import 'package:flutter/material.dart';

/// Shared loading indicator used across features while an [AsyncValue]
/// is in its loading state. Kept in `shared/` because it has no
/// feature-specific logic.
class LoadingIndicator extends StatelessWidget {
  const LoadingIndicator({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(child: CircularProgressIndicator());
  }
}
