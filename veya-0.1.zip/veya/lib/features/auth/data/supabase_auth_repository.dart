import 'package:supabase_flutter/supabase_flutter.dart' as sb;

import '../../../core/error/failure.dart';
import '../../../core/logging/app_logger.dart';
import '../domain/app_user.dart';
import '../domain/auth_repository.dart';

/// Supabase implementation of [AuthRepository].
///
/// This is the ONLY file in the `auth` feature allowed to import
/// `supabase_flutter`. Every Supabase-specific exception is caught here and
/// mapped into a typed [Failure] — nothing above this layer should ever
/// see a raw `AuthException`/`PostgrestException`.
class SupabaseAuthRepository implements AuthRepository {
  SupabaseAuthRepository();

  final sb.SupabaseClient _client = sb.Supabase.instance.client;

  @override
  Stream<AppUser?> authStateChanges() {
    return _client.auth.onAuthStateChange.map((event) {
      final user = event.session?.user;
      if (user == null) return null;
      return AppUser(id: user.id, email: user.email);
    });
  }

  @override
  AppUser? get currentUser {
    final user = _client.auth.currentUser;
    if (user == null) return null;
    return AppUser(id: user.id, email: user.email);
  }

  @override
  Future<void> signUp({required String email, required String password}) async {
    try {
      await _client.auth.signUp(email: email, password: password);
    } on sb.AuthException catch (e, st) {
      AppLogger.error('signUp failed', error: e, stackTrace: st);
      throw AuthFailure(_mapAuthMessage(e), code: e.code);
    } catch (e, st) {
      AppLogger.error('signUp unexpected error', error: e, stackTrace: st);
      throw const NetworkFailure();
    }
  }

  @override
  Future<void> signIn({required String email, required String password}) async {
    try {
      await _client.auth.signInWithPassword(email: email, password: password);
    } on sb.AuthException catch (e, st) {
      AppLogger.error('signIn failed', error: e, stackTrace: st);
      throw AuthFailure(_mapAuthMessage(e), code: e.code);
    } catch (e, st) {
      AppLogger.error('signIn unexpected error', error: e, stackTrace: st);
      throw const NetworkFailure();
    }
  }

  @override
  Future<void> signOut() async {
    try {
      await _client.auth.signOut();
    } on sb.AuthException catch (e, st) {
      AppLogger.error('signOut failed', error: e, stackTrace: st);
      throw AuthFailure(_mapAuthMessage(e), code: e.code);
    }
  }

  /// Maps raw Supabase auth error codes/messages to user-safe text.
  /// Never returns the raw exception message directly (avoids leaking
  /// backend implementation details — see SECURITY_DECISIONS.md).
  String _mapAuthMessage(sb.AuthException e) {
    switch (e.code) {
      case 'invalid_credentials':
        return 'Incorrect email or password.';
      case 'email_exists':
      case 'user_already_exists':
        return 'An account with this email already exists.';
      case 'weak_password':
        return 'Password is too weak. Use at least 8 characters.';
      case 'over_email_send_rate_limit':
        return 'Too many attempts. Please wait and try again.';
      default:
        return 'Authentication failed. Please try again.';
    }
  }
}
