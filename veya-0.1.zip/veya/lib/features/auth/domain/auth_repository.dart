import '../../../core/error/failure.dart';
import 'app_user.dart';

/// Domain-defined contract for authentication.
/// `data/` implements this against Supabase; `application/` and
/// `presentation/` only ever depend on this interface, never on
/// `supabase_flutter` directly.
abstract interface class AuthRepository {
  /// Emits the current auth state whenever it changes (sign in, sign out,
  /// token refresh, session expiry). `null` means unauthenticated.
  Stream<AppUser?> authStateChanges();

  AppUser? get currentUser;

  Future<void> signUp({required String email, required String password});

  Future<void> signIn({required String email, required String password});

  Future<void> signOut();
}

/// Wraps a [Failure] for call sites that prefer a typed result over
/// try/catch at every call site. Repository implementations throw
/// [Failure] subtypes; this is a convenience alias for documentation.
typedef AuthResult = Future<void> Function();
