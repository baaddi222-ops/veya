/// Domain-level representation of an authenticated user.
/// Deliberately minimal — pure Dart, no Supabase types leak into the domain.
class AppUser {
  const AppUser({required this.id, required this.email});

  final String id;
  final String? email;
}
