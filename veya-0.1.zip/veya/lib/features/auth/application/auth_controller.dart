import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/error/failure.dart';
import '../../../core/logging/app_logger.dart';
import '../data/supabase_auth_repository.dart';
import '../domain/app_user.dart';
import '../domain/auth_repository.dart';

/// Provides the concrete [AuthRepository]. This is the only place outside
/// `data/` that knows a concrete Supabase-backed implementation exists —
/// note it does NOT import `package:supabase_flutter` itself; the
/// repository implementation owns its own client lookup.
final authRepositoryProvider = Provider<AuthRepository>((ref) {
  return SupabaseAuthRepository();
});

/// VEYA 0.1-D — unified authentication state.
///
/// One flat, explicit state machine (not a boolean, not `AsyncValue`
/// layered on top of a separate 2-state enum as in 0.1-C). Every consumer
/// (router, screens) switches on exactly one of these six states, so
/// "is authentication still being resolved?" and "is an auth action in
/// flight?" are both first-class, nameable states rather than something
/// inferred from loading flags.
sealed class AuthState {
  const AuthState();
}

/// Before the underlying Supabase session stream has emitted its first
/// value. The router treats this specially: no redirect decision is made
/// yet, and a splash screen is shown instead of guessing — this is what
/// prevents a wrong-screen flash while a persisted session is being
/// restored from local storage on cold start.
final class AuthInitializing extends AuthState {
  const AuthInitializing();
}

final class AuthUnauthenticated extends AuthState {
  const AuthUnauthenticated();
}

/// A sign-in or sign-up call is in flight. Kept distinct from
/// [AuthUnauthenticated] so the UI can show a submitting state without the
/// router treating it any differently for access purposes — an in-flight
/// authentication attempt must never grant protected access before it
/// actually succeeds (fail closed).
final class AuthAuthenticating extends AuthState {
  const AuthAuthenticating();
}

final class AuthAuthenticated extends AuthState {
  const AuthAuthenticated(this.user);
  final AppUser user;
}

/// A sign-out call is in flight. Routing-wise this is treated identically
/// to [AuthUnauthenticated] (protected screens stop being reachable the
/// instant sign-out begins, not only once the network call completes) —
/// see core/router/app_router.dart.
final class AuthSigningOut extends AuthState {
  const AuthSigningOut();
}

/// A sign-in/sign-up attempt failed, or the underlying session stream
/// itself errored. Routing-wise this is treated the same as
/// [AuthUnauthenticated] — an error resolving identity is never treated as
/// "authenticated" (fail closed), it only carries the [Failure] so the
/// current screen (normally SignInScreen/SignUpScreen) can display it.
final class AuthenticationError extends AuthState {
  const AuthenticationError(this.failure);
  final Failure failure;
}

/// Single source of truth for authentication state.
///
/// Subscribes exactly once to [AuthRepository.authStateChanges] in
/// [build], cancels that subscription in [ref.onDispose] — there is only
/// ever one listener on the underlying stream for the lifetime of this
/// notifier (see test/unit/auth_notifier_test.dart, which asserts this
/// directly against a fake repository's StreamController).
///
/// `signIn`/`signUp`/`signOut` set an in-flight state immediately, then
/// resolve the outcome explicitly from the repository call's result rather
/// than only waiting for the session stream to eventually catch up — this
/// guarantees no stale/delayed state (the exact requirement in the 0.1-D
/// spec §8: "avoid leaving stale authenticated state in providers").
class AuthNotifier extends Notifier<AuthState> {
  StreamSubscription<AppUser?>? _subscription;

  @override
  AuthState build() {
    final repo = ref.watch(authRepositoryProvider);

    _subscription = repo.authStateChanges().listen(
      (user) {
        state = user == null ? const AuthUnauthenticated() : AuthAuthenticated(user);
      },
      onError: (Object error, StackTrace stackTrace) {
        AppLogger.error('Auth state stream error', error: error, stackTrace: stackTrace);
        // Fail closed: if we cannot determine auth state, treat it as
        // unauthenticated — never as authenticated.
        state = const AuthUnauthenticated();
      },
    );

    ref.onDispose(() {
      _subscription?.cancel();
      _subscription = null;
    });

    return const AuthInitializing();
  }

  Future<void> signIn({required String email, required String password}) async {
    state = const AuthAuthenticating();
    final repo = ref.read(authRepositoryProvider);
    try {
      await repo.signIn(email: email, password: password);
      final user = repo.currentUser;
      state = user != null ? AuthAuthenticated(user) : const AuthUnauthenticated();
    } on Failure catch (failure) {
      state = AuthenticationError(failure);
    } catch (error, stackTrace) {
      AppLogger.error('signIn: unmapped error', error: error, stackTrace: stackTrace);
      state = const AuthenticationError(UnknownFailure());
    }
  }

  Future<void> signUp({required String email, required String password}) async {
    state = const AuthAuthenticating();
    final repo = ref.read(authRepositoryProvider);
    try {
      await repo.signUp(email: email, password: password);
      final user = repo.currentUser;
      state = user != null ? AuthAuthenticated(user) : const AuthUnauthenticated();
    } on Failure catch (failure) {
      state = AuthenticationError(failure);
    } catch (error, stackTrace) {
      AppLogger.error('signUp: unmapped error', error: error, stackTrace: stackTrace);
      state = const AuthenticationError(UnknownFailure());
    }
  }

  Future<void> signOut() async {
    state = const AuthSigningOut();
    final repo = ref.read(authRepositoryProvider);
    try {
      await repo.signOut();
    } on Failure catch (failure) {
      // Sign-out failing remotely is unusual, but we still force local
      // state to unauthenticated immediately — never leave the app
      // reporting "authenticated" once sign-out has been requested, even
      // if the remote call had trouble. The failure is logged, not shown
      // as a blocking error, since the user's intent (leave the account)
      // is honored locally regardless.
      AppLogger.error('signOut: remote call failed, forcing local sign-out anyway',
          error: failure);
    } finally {
      state = const AuthUnauthenticated();
    }
  }
}

final authProvider = NotifierProvider<AuthNotifier, AuthState>(AuthNotifier.new);
