import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/error/failure.dart';
import '../application/profile_controller.dart';
import '../domain/profile.dart';
import '../domain/profile_update.dart';
import '../domain/profile_validators.dart';

/// Edit-profile flow (0.1-E §14):
///
/// ProfileScreen -> EditProfileScreen -> MyProfileController -> ProfileRepository -> Supabase
///
/// The UI never touches Supabase directly. No optimistic UI (0.1-E §15):
/// the form stays on this screen, showing a saving state, until the
/// repository call actually resolves — only a confirmed server result
/// closes the screen. The save button is disabled while a save is already
/// in flight (0.1-E §16), which is what prevents duplicate submissions.
///
/// Only `username`, `displayName`, and `bio` are editable here.
/// `avatarUrl` is deliberately NOT exposed as a text field: there is no
/// avatar upload pipeline in 0.1-E (that is explicitly future scope — see
/// docs/adr/0013-avatar-field-without-upload-pipeline.md), and offering a
/// raw "paste an avatar URL" field would both invite users to point it at
/// arbitrary/untrusted content and pre-empt the real upload design that
/// belongs to a later release.
class EditProfileScreen extends ConsumerStatefulWidget {
  const EditProfileScreen({required this.profile, super.key});

  final Profile profile;

  @override
  ConsumerState<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends ConsumerState<EditProfileScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _usernameController;
  late final TextEditingController _displayNameController;
  late final TextEditingController _bioController;

  @override
  void initState() {
    super.initState();
    _usernameController = TextEditingController(text: widget.profile.username);
    _displayNameController = TextEditingController(text: widget.profile.displayName ?? '');
    _bioController = TextEditingController(text: widget.profile.bio ?? '');
  }

  @override
  void dispose() {
    _usernameController.dispose();
    _displayNameController.dispose();
    _bioController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;

    // Only send fields that actually changed — avoids an unnecessary write
    // to unchanged columns and keeps the update minimal (0.1-E §18).
    final newUsername = _usernameController.text.trim();
    final newDisplayName = _displayNameController.text.trim();
    final newBio = _bioController.text.trim();

    final update = ProfileUpdate(
      username: newUsername != widget.profile.username ? newUsername : null,
      displayName: newDisplayName != (widget.profile.displayName ?? '') ? newDisplayName : null,
      bio: newBio != (widget.profile.bio ?? '') ? newBio : null,
    );

    if (update.isEmpty) {
      if (mounted) Navigator.of(context).pop();
      return;
    }

    await ref.read(myProfileProvider.notifier).update(update);

    // Only pop on success — an error is surfaced by the ref.listen below
    // and the user stays on the form to correct it (e.g. duplicate
    // username), matching 0.1-E §14's explicit "handle validation error"
    // requirement rather than closing the screen regardless of outcome.
    final state = ref.read(myProfileProvider);
    if (mounted && !state.hasError) {
      Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    final profileAsync = ref.watch(myProfileProvider);
    final isSaving = profileAsync.isLoading;

    ref.listen(myProfileProvider, (previous, next) {
      final error = next.error;
      if (error is Failure && context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(error.message)),
        );
      }
    });

    return Scaffold(
      appBar: AppBar(title: const Text('Edit profile')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextFormField(
                key: const Key('editProfileUsernameField'),
                controller: _usernameController,
                decoration: const InputDecoration(prefixText: '@', labelText: 'Username'),
                autovalidateMode: AutovalidateMode.onUserInteraction,
                validator: ProfileValidators.username,
              ),
              const SizedBox(height: 16),
              TextFormField(
                key: const Key('editProfileDisplayNameField'),
                controller: _displayNameController,
                decoration: const InputDecoration(labelText: 'Display name (optional)'),
                autovalidateMode: AutovalidateMode.onUserInteraction,
                validator: ProfileValidators.displayName,
              ),
              const SizedBox(height: 16),
              TextFormField(
                key: const Key('editProfileBioField'),
                controller: _bioController,
                decoration: const InputDecoration(labelText: 'Bio (optional)'),
                autovalidateMode: AutovalidateMode.onUserInteraction,
                validator: ProfileValidators.bio,
                maxLines: 3,
              ),
              const SizedBox(height: 24),
              FilledButton(
                key: const Key('editProfileSaveButton'),
                onPressed: isSaving ? null : _submit,
                child: isSaving
                    ? const SizedBox(
                        height: 16,
                        width: 16,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Text('Save'),
              ),
              const SizedBox(height: 8),
              TextButton(
                key: const Key('editProfileCancelButton'),
                onPressed: isSaving ? null : () => Navigator.of(context).pop(),
                child: const Text('Cancel'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
