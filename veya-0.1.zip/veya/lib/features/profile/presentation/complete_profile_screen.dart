import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/error/failure.dart';
import '../application/profile_controller.dart';
import '../domain/profile_update.dart';
import '../domain/profile_validators.dart';

/// Shown once, right after signup, while the user's profile still has the
/// trigger-generated placeholder username (see [Profile.hasPlaceholderUsername]
/// and ADR-0009). Closes the gap flagged as a known limitation in
/// docs/RELEASE_STATUS.md: the trigger deliberately creates a safe,
/// collision-proof placeholder rather than deriving one from the user's
/// email, and the app is expected to prompt for a real one afterward.
class CompleteProfileScreen extends ConsumerStatefulWidget {
  const CompleteProfileScreen({super.key});

  @override
  ConsumerState<CompleteProfileScreen> createState() => _CompleteProfileScreenState();
}

class _CompleteProfileScreenState extends ConsumerState<CompleteProfileScreen> {
  final _formKey = GlobalKey<FormState>();
  final _usernameController = TextEditingController();

  @override
  void dispose() {
    _usernameController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    await ref.read(myProfileProvider.notifier).update(
          ProfileUpdate(username: _usernameController.text.trim()),
        );
  }

  @override
  Widget build(BuildContext context) {
    final profileAsync = ref.watch(myProfileProvider);
    final isLoading = profileAsync.isLoading;

    ref.listen(myProfileProvider, (previous, next) {
      final error = next.error;
      // Only surface an error here if we're still showing this screen (i.e.
      // the update failed rather than succeeded and moved us on) — a
      // duplicate-username ValidationFailure is the expected case.
      if (error is Failure && context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(error.message)),
        );
      }
    });

    return Scaffold(
      appBar: AppBar(title: const Text('Choose your username')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                "You're almost set. Pick a username — you can change it "
                'later from your profile.',
              ),
              const SizedBox(height: 24),
              TextFormField(
                key: const Key('completeProfileUsernameField'),
                controller: _usernameController,
                decoration: const InputDecoration(
                  prefixText: '@',
                  labelText: 'Username',
                ),
                autovalidateMode: AutovalidateMode.onUserInteraction,
                validator: ProfileValidators.username,
              ),
              const SizedBox(height: 24),
              FilledButton(
                key: const Key('completeProfileSubmitButton'),
                onPressed: isLoading ? null : _submit,
                child: isLoading
                    ? const SizedBox(
                        height: 16,
                        width: 16,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Text('Continue'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
