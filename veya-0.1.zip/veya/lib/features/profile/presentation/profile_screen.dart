import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/error/failure.dart';
import '../../../shared/widgets/loading_indicator.dart';
import '../../auth/application/auth_controller.dart';
import '../application/profile_controller.dart';
import 'edit_profile_screen.dart';

class ProfileScreen extends ConsumerWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profileAsync = ref.watch(myProfileProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
        actions: [
          IconButton(
            key: const Key('signOutButton'),
            icon: const Icon(Icons.logout),
            onPressed: () => ref.read(authProvider.notifier).signOut(),
          ),
        ],
      ),
      body: profileAsync.when(
        loading: () => const LoadingIndicator(),
        error: (error, stackTrace) {
          final message = error is Failure ? error.message : 'Could not load profile.';
          return Center(child: Text(message));
        },
        data: (profile) {
          // avatarUrl already exists as a profile field (and is already
          // safely settable via the repository/RLS boundary) but has no
          // upload pipeline yet in 0.1-E — see
          // docs/adr/0013-avatar-field-without-upload-pipeline.md. Only
          // *display* is added here, using whatever value already exists.
          final avatar = CircleAvatar(
            key: const Key('profileAvatar'),
            radius: 32,
            backgroundImage: profile.avatarUrl != null ? NetworkImage(profile.avatarUrl!) : null,
            child: profile.avatarUrl == null
                ? Text(
                    profile.username.isNotEmpty ? profile.username[0].toUpperCase() : '?',
                    style: const TextStyle(fontSize: 24),
                  )
                : null,
          );

          return Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    avatar,
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '@${profile.username}',
                            style: Theme.of(context).textTheme.headlineSmall,
                          ),
                          if (profile.displayName != null) Text(profile.displayName!),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                if (profile.bio != null) Text(profile.bio!),
                const SizedBox(height: 24),
                OutlinedButton(
                  key: const Key('editProfileButton'),
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) => EditProfileScreen(profile: profile),
                    ),
                  ),
                  child: const Text('Edit profile'),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
