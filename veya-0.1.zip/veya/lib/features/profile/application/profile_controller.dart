import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../data/supabase_profile_repository.dart';
import '../domain/profile.dart';
import '../domain/profile_repository.dart';
import '../domain/profile_update.dart';

final profileRepositoryProvider = Provider<ProfileRepository>((ref) {
  return SupabaseProfileRepository();
});

/// Loads and holds the current user's own profile.
final myProfileProvider = AsyncNotifierProvider<MyProfileController, Profile>(
  MyProfileController.new,
);

class MyProfileController extends AsyncNotifier<Profile> {
  @override
  Future<Profile> build() {
    return ref.read(profileRepositoryProvider).getMyProfile();
  }

  /// Submits [update] and waits for the confirmed server result before
  /// reflecting it in state — no optimistic update (0.1-E §15: the social
  /// feed doesn't exist yet, so there's no reason to introduce that
  /// complexity ahead of needing it). While `state` is `AsyncLoading`,
  /// UI built on this provider is expected to disable its own save
  /// control (see EditProfileScreen/CompleteProfileScreen), which is what
  /// actually prevents duplicate submissions — `AsyncNotifier` does not
  /// itself de-duplicate concurrent calls to this method.
  Future<void> update(ProfileUpdate profileUpdate) async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(() {
      return ref.read(profileRepositoryProvider).updateMyProfile(profileUpdate);
    });
  }
}
