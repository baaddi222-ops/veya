import 'package:supabase_flutter/supabase_flutter.dart' as sb;

import '../../../core/error/failure.dart';
import '../../../core/logging/app_logger.dart';
import '../domain/profile.dart';
import '../domain/profile_repository.dart';
import '../domain/profile_update.dart';

/// Supabase implementation of [ProfileRepository].
///
/// Only this file imports `supabase_flutter` within the `profile` feature.
/// Every query relies on RLS and 0.1-C's column-level grants (owner-only,
/// restricted-column UPDATE — see docs/SECURITY_DECISIONS.md) as the
/// actual access boundary; this class does not attempt to duplicate that
/// logic client-side, and [ProfileUpdate] already ensures only the
/// allowed fields can be expressed here in the first place.
class SupabaseProfileRepository implements ProfileRepository {
  SupabaseProfileRepository();

  final sb.SupabaseClient _client = sb.Supabase.instance.client;

  static const _table = 'profiles';

  @override
  Future<Profile> getMyProfile() async {
    final userId = _client.auth.currentUser?.id;
    if (userId == null) {
      throw const AuthFailure('You must be signed in.');
    }
    try {
      final row = await _client.from(_table).select().eq('id', userId).single();
      return _fromRow(row);
    } on sb.PostgrestException catch (e, st) {
      AppLogger.error('getMyProfile failed', error: e, stackTrace: st);
      throw const UnknownFailure('Could not load your profile.');
    }
  }

  @override
  Future<Profile> updateMyProfile(ProfileUpdate update) async {
    final userId = _client.auth.currentUser?.id;
    if (userId == null) {
      throw const AuthFailure('You must be signed in.');
    }
    if (update.isEmpty) {
      // Nothing to do — avoid an unnecessary round trip for a no-op save.
      return getMyProfile();
    }
    try {
      final row = await _client
          .from(_table)
          .update(update.toColumnMap())
          .eq('id', userId) // defense in depth — RLS enforces this too
          .select()
          .single();
      return _fromRow(row);
    } on sb.PostgrestException catch (e, st) {
      AppLogger.error('updateMyProfile failed', error: e, stackTrace: st);
      if (e.code == '23505') {
        throw const ValidationFailure('That username is already taken.');
      }
      if (e.code == '23514') {
        // A CHECK constraint fired server-side (e.g. display_name/bio too
        // long) even though the client validated first — belt-and-braces,
        // since the database remains the authoritative boundary (0.1-C).
        throw const ValidationFailure('One of the values you entered is not valid.');
      }
      throw const UnknownFailure('Could not update your profile.');
    }
  }

  Profile _fromRow(Map<String, dynamic> row) {
    return Profile(
      id: row['id'] as String,
      username: row['username'] as String,
      displayName: row['display_name'] as String?,
      avatarUrl: row['avatar_url'] as String?,
      bio: row['bio'] as String?,
      accountStatus: row['account_status'] as String,
      createdAt: DateTime.parse(row['created_at'] as String),
    );
  }
}
