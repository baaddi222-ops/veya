/// Domain entity for a VEYA profile.
/// Pure Dart — no Supabase types. Matches the `profiles` table shape
/// documented in docs/DATABASE_SCHEMA.md.
class Profile {
  const Profile({
    required this.id,
    required this.username,
    this.displayName,
    this.avatarUrl,
    this.bio,
    required this.accountStatus,
    required this.createdAt,
  });

  final String id;
  final String username;
  final String? displayName;
  final String? avatarUrl;
  final String? bio;
  final String accountStatus;
  final DateTime createdAt;

  /// True when [username] still matches the trigger-generated placeholder
  /// pattern (`user_` + 8 hex chars — see migration
  /// 0003_create_signup_trigger.sql / ADR-0009). Used to route a freshly
  /// signed-up user to CompleteProfileScreen instead of ProfileScreen until
  /// they choose a real username.
  static final RegExp _placeholderPattern = RegExp(r'^user_[0-9a-f]{8}$');
  bool get hasPlaceholderUsername => _placeholderPattern.hasMatch(username);

  Profile copyWith({
    String? username,
    String? displayName,
    String? avatarUrl,
    String? bio,
  }) {
    return Profile(
      id: id,
      username: username ?? this.username,
      displayName: displayName ?? this.displayName,
      avatarUrl: avatarUrl ?? this.avatarUrl,
      bio: bio ?? this.bio,
      accountStatus: accountStatus,
      createdAt: createdAt,
    );
  }
}
