/// Typed value object for the fields an authenticated user may change on
/// their own profile.
///
/// This exists specifically so the UI (and any future caller) cannot
/// construct an arbitrary update map by accident — before 0.1-E,
/// `ProfileRepository.updateMyProfile` took four loose named `String?`
/// parameters, which is easy to extend later with an unintended field
/// (e.g. a well-meaning future PR adding `accountStatus` as "just another
/// parameter"). `ProfileUpdate` declares, in one place, exactly the closed
/// set of fields that are ever updatable — there is no field here for
/// `id`, `createdAt`, `updatedAt`, or `accountStatus`, and there
/// structurally cannot be one without a deliberate, reviewed change to
/// this file.
///
/// This is a Dart-level, compile-time-visible restriction — it is a
/// second, independent layer on top of the actual security boundary
/// (0.1-C's column-level database grants, which restrict `UPDATE` to
/// exactly `username, display_name, avatar_url, bio` at the database
/// level regardless of what any client sends). Neither layer replaces the
/// other.
class ProfileUpdate {
  const ProfileUpdate({
    this.username,
    this.displayName,
    this.avatarUrl,
    this.bio,
  });

  final String? username;
  final String? displayName;
  final String? avatarUrl;
  final String? bio;

  bool get isEmpty =>
      username == null && displayName == null && avatarUrl == null && bio == null;

  /// Renders to the exact column-name map the Supabase implementation
  /// needs, including only fields that were actually set. Kept here
  /// (rather than duplicated inside the repository implementation) so
  /// there is exactly one place that maps domain field names to database
  /// column names.
  Map<String, dynamic> toColumnMap() => {
        if (username != null) 'username': username,
        if (displayName != null) 'display_name': displayName,
        if (avatarUrl != null) 'avatar_url': avatarUrl,
        if (bio != null) 'bio': bio,
      };
}
