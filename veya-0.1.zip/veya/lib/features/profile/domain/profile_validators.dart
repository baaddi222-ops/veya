import '../../../core/constants/app_constants.dart';

/// Shared, pure-Dart validation for profile fields.
///
/// Extracted into one place in 0.1-E specifically to avoid the exact
/// problem the spec calls out: `CompleteProfileScreen` already had its own
/// inline username regex/length check, and a new edit-profile screen would
/// otherwise duplicate it — with a real risk of the two silently drifting
/// out of sync with each other, and with the database's own CHECK
/// constraints (migrations 0001, 0007), over time. These functions mirror
/// the database constraints exactly and are the single place both screens
/// (and any future one) call into.
///
/// These are advisory/UX-layer checks only — the database constraints are
/// the actual, authoritative boundary (0.1-C's principle: never trust the
/// client as the security boundary). Returns a user-facing error message,
/// or `null` if the value is valid.
class ProfileValidators {
  const ProfileValidators._();

  static final RegExp _usernameFormat = RegExp(r'^[a-z0-9_]+$');

  /// Mirrors migration 0001's `profiles_username_length` and
  /// `profiles_username_format` CHECK constraints exactly.
  static String? username(String? value) {
    final trimmed = (value ?? '').trim();
    if (trimmed.length < AppConstants.usernameMinLength ||
        trimmed.length > AppConstants.usernameMaxLength) {
      return 'Username must be ${AppConstants.usernameMinLength}-'
          '${AppConstants.usernameMaxLength} characters';
    }
    if (!_usernameFormat.hasMatch(trimmed)) {
      return 'Lowercase letters, numbers, and underscores only';
    }
    return null;
  }

  /// Mirrors migration 0007's `profiles_display_name_length` CHECK
  /// constraint. Optional field — an empty/null value is valid (clears the
  /// display name). Unicode is counted by codepoint (`.characters.length`
  /// equivalent via runes), matching the database's `char_length()`, not
  /// UTF-16 code unit count — so e.g. emoji or combined characters are not
  /// unfairly penalized relative to what the database will actually accept.
  static String? displayName(String? value) {
    if (value == null || value.trim().isEmpty) return null;
    final length = value.trim().runes.length;
    if (length > AppConstants.displayNameMaxLength) {
      return 'Display name must be ${AppConstants.displayNameMaxLength} characters or fewer';
    }
    return null;
  }

  /// Mirrors migration 0001's `profiles_bio_length` CHECK constraint.
  static String? bio(String? value) {
    if (value == null || value.trim().isEmpty) return null;
    final length = value.trim().runes.length;
    if (length > AppConstants.bioMaxLength) {
      return 'Bio must be ${AppConstants.bioMaxLength} characters or fewer';
    }
    return null;
  }
}
