import 'profile.dart';
import 'profile_update.dart';

/// Domain contract for reading/updating the CURRENT user's own profile.
///
/// 0.1 deliberately exposes no "get another user's profile" method — per
/// the approved 0.1 privacy decision, all profile access is owner-only, so
/// there is nothing else to fetch yet. Adding a `getProfile(otherUserId)`
/// method is 0.2 scope, alongside the RLS policy that would make it
/// meaningful.
abstract interface class ProfileRepository {
  Future<Profile> getMyProfile();

  Future<Profile> updateMyProfile(ProfileUpdate update);
}
