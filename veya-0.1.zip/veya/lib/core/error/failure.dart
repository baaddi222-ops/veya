/// Domain-level failure types. Data-layer exceptions (Postgrest/Auth/network)
/// are mapped into these at the repository boundary — nothing above `data/`
/// should ever see a raw Supabase exception.
sealed class Failure {
  const Failure(this.message);

  /// User-safe, already-appropriate-to-display message.
  /// Never the raw exception string from the backend.
  final String message;
}

final class AuthFailure extends Failure {
  const AuthFailure(super.message, {this.code});
  final String? code;
}

final class NetworkFailure extends Failure {
  const NetworkFailure([super.message = 'Network connection problem.']);
}

final class ValidationFailure extends Failure {
  const ValidationFailure(super.message);
}

final class UnknownFailure extends Failure {
  const UnknownFailure([super.message = 'Something went wrong.']);
}
