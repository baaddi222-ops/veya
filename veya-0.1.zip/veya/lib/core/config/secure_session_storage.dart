import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// Persists the Supabase session (including the access/refresh token) via
/// the platform's encrypted secure storage (Keychain on iOS/macOS,
/// EncryptedSharedPreferences/Keystore-backed on Android) instead of
/// `supabase_flutter`'s own default `LocalStorage`, which — as of the
/// pinned `supabase_flutter: ^2.5.6` — persists the session via plain
/// `SharedPreferences`: sandboxed per-app by the OS, but not encrypted at
/// rest.
///
/// This closes the real, specific gap found and documented during the
/// 0.1-D audit (see docs/SECURITY_DECISIONS.md and
/// docs/adr/0012-encrypted-session-storage.md for the full reasoning,
/// including the counter-argument for why supabase_flutter defaults to
/// SharedPreferences in the first place — this is a deliberate hardening
/// choice for VEYA specifically, not a claim that the SDK default is
/// simply wrong).
///
/// Implements the exact `LocalStorage` constructor shape documented by
/// Supabase for a custom storage backend: `initialize`, `hasAccessToken`,
/// `accessToken`, `persistSession`, `removePersistedSession`.
class SecureSessionStorage extends LocalStorage {
  SecureSessionStorage()
      : super(
          initialize: () async {},
          hasAccessToken: () async {
            const storage = FlutterSecureStorage();
            return storage.containsKey(key: supabasePersistSessionKey);
          },
          accessToken: () async {
            const storage = FlutterSecureStorage();
            return storage.read(key: supabasePersistSessionKey);
          },
          persistSession: (String value) async {
            const storage = FlutterSecureStorage();
            await storage.write(key: supabasePersistSessionKey, value: value);
          },
          removePersistedSession: () async {
            const storage = FlutterSecureStorage();
            await storage.delete(key: supabasePersistSessionKey);
          },
        );
}
