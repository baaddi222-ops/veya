/// Centralized environment/config access.
///
/// Values are injected at compile time via `--dart-define-from-file`.
/// This is the ONLY place in the app that should read `String.fromEnvironment`.
///
/// Only client-safe values belong here: the Supabase project URL and the
/// **anon/public** key. The Supabase service-role key must NEVER be read
/// here or anywhere else in this Flutter application.
class Env {
  const Env._();

  static const String supabaseUrl = String.fromEnvironment(
    'SUPABASE_URL',
    defaultValue: '',
  );

  static const String supabaseAnonKey = String.fromEnvironment(
    'SUPABASE_ANON_KEY',
    defaultValue: '',
  );

  static const String appEnv = String.fromEnvironment(
    'APP_ENV',
    defaultValue: 'dev',
  );

  /// Fails fast and loudly at startup rather than silently running with an
  /// empty backend config, which would otherwise surface as confusing
  /// downstream Supabase errors.
  static void assertConfigured() {
    if (supabaseUrl.isEmpty || supabaseAnonKey.isEmpty) {
      throw StateError(
        'Missing SUPABASE_URL / SUPABASE_ANON_KEY. '
        'Run with --dart-define-from-file=.env.json (see .env.example).',
      );
    }
  }
}
