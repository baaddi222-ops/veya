import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../features/auth/application/auth_controller.dart';
import '../../features/auth/presentation/sign_in_screen.dart';
import '../../features/auth/presentation/sign_up_screen.dart';
import '../../features/profile/application/profile_controller.dart';
import '../../features/profile/presentation/complete_profile_screen.dart';
import '../../features/profile/presentation/profile_screen.dart';
import '../error/failure.dart';
import '../../shared/widgets/loading_indicator.dart';

/// Centralized auth-aware router. Every redirect decision for
/// authenticated/unauthenticated access lives HERE, not scattered as
/// `if` checks across individual screens (0.1-D §12).
///
/// Redirect rule, expressed on the flat [AuthState] from 0.1-D:
///   - [AuthInitializing]      -> no redirect yet, splash shown at '/'
///   - [AuthAuthenticated]     -> redirected OFF /sign-in and /sign-up
///   - every other state       -> redirected TO /sign-in unless already on
///     ([AuthUnauthenticated],    an auth route
///      [AuthAuthenticating],
///      [AuthSigningOut],
///      [AuthenticationError])
///
/// The "every other state" branch is deliberately broad and fail-closed:
/// an in-flight sign-in, an in-flight sign-out, and an auth error are all
/// treated identically to plain unauthenticated for ROUTING purposes. This
/// guarantees a protected route can never be reached on the strength of a
/// state that isn't a confirmed [AuthAuthenticated] — see 0.1-D §7 ("do not
/// silently create a new identity") and §17 (fail-closed on ambiguity).
final routerProvider = Provider<GoRouter>((ref) {
  final authState = ref.watch(authProvider);

  return GoRouter(
    initialLocation: '/',
    refreshListenable: _AuthRefreshNotifier(ref),
    redirect: (context, state) {
      final path = state.matchedLocation;
      final isAuthRoute = path == '/sign-in' || path == '/sign-up';

      return switch (authState) {
        AuthInitializing() => null,
        AuthAuthenticated() => isAuthRoute ? '/' : null,
        AuthUnauthenticated() ||
        AuthAuthenticating() ||
        AuthSigningOut() ||
        AuthenticationError() =>
          isAuthRoute ? null : '/sign-in',
      };
    },
    routes: [
      GoRoute(
        path: '/',
        builder: (context, state) => switch (authState) {
          AuthAuthenticated() => const _HomeGate(),
          _ => const _SplashScreen(),
        },
      ),
      GoRoute(path: '/sign-in', builder: (context, state) => const SignInScreen()),
      GoRoute(path: '/sign-up', builder: (context, state) => const SignUpScreen()),
      GoRoute(path: '/profile', builder: (context, state) => const _HomeGate()),
    ],
  );
});

/// For an authenticated user, decides between [CompleteProfileScreen]
/// (placeholder username still in place — see ADR-0009 and
/// [Profile.hasPlaceholderUsername]) and [ProfileScreen] (real username
/// already chosen). Kept as its own widget, rather than inline in the
/// route builder, because it needs to watch [myProfileProvider] as well as
/// auth state. Reached only when [authProvider] is [AuthAuthenticated] —
/// the redirect above guarantees that; this widget does not re-check auth
/// itself, since the router is the single source of truth for that
/// decision (0.1-D §12).
class _HomeGate extends ConsumerWidget {
  const _HomeGate();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profileAsync = ref.watch(myProfileProvider);

    return profileAsync.when(
      loading: () => const _SplashScreen(),
      error: (error, stackTrace) {
        final message = error is Failure ? error.message : 'Could not load profile.';
        return Scaffold(body: Center(child: Text(message)));
      },
      data: (profile) => profile.hasPlaceholderUsername
          ? const CompleteProfileScreen()
          : const ProfileScreen(),
    );
  }
}

/// Bridges Riverpod's [authProvider] into a `Listenable` so go_router
/// re-evaluates `redirect` whenever auth state changes (sign in, sign out,
/// expiry, error). `ref.listen` here adds one callback to the SAME
/// underlying stream subscription [AuthNotifier] already owns — it does
/// NOT create a second subscription (Riverpod providers are cached per
/// container), so there is exactly one listener on the auth stream for the
/// app's lifetime, not one per router build. This directly satisfies 0.1-D
/// §6 ("avoid creating multiple uncontrolled listeners").
class _AuthRefreshNotifier extends ChangeNotifier {
  _AuthRefreshNotifier(Ref ref) {
    ref.listen(authProvider, (_, __) => notifyListeners());
  }
}

class _SplashScreen extends StatelessWidget {
  const _SplashScreen();

  @override
  Widget build(BuildContext context) {
    return const Scaffold(body: LoadingIndicator());
  }
}
