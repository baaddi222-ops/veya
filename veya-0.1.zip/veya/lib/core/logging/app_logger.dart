import 'dart:developer' as developer;

/// Thin logging wrapper — no `print()` calls anywhere else in the app.
///
/// 0.1 logs to the console in debug builds only. Structured so a remote sink
/// (crash/error reporting) can be added later without touching call sites.
///
/// NEVER pass tokens, passwords, or raw user PII into these calls.
class AppLogger {
  const AppLogger._();

  static void debug(String message) => _log(message, level: 500, name: 'debug');
  static void info(String message) => _log(message, level: 800, name: 'info');
  static void warn(String message) => _log(message, level: 900, name: 'warn');

  static void error(String message, {Object? error, StackTrace? stackTrace}) {
    developer.log(
      message,
      level: 1000,
      name: 'veya.error',
      error: error,
      stackTrace: stackTrace,
    );
  }

  static void _log(String message, {required int level, required String name}) {
    developer.log(message, level: level, name: 'veya.$name');
  }
}
