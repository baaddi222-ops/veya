/// App-wide, non-secret constants.
class AppConstants {
  const AppConstants._();

  static const String appName = 'VEYA';

  static const int usernameMinLength = 3;
  static const int usernameMaxLength = 24;
  static const int bioMaxLength = 280;
  static const int displayNameMaxLength = 50;
}
