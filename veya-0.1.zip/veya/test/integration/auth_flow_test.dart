// VEYA 0.1 — integration test
// STATUS: BLOCKED in this container — requires BOTH a Flutter SDK to run
// `flutter test integration_test` (or `flutter drive`) AND a live,
// network-reachable Supabase test project to sign real users up against.
// Neither is available in this environment. This file documents the
// intended coverage; it is not a placeholder to be deleted once a real
// environment exists — it should be filled in and actually run there.
//
// Intended coverage once runnable:
//   1. Sign up a new unique test user -> exactly one profiles row and one
//      user_privacy_settings row exist (verifies the 0003 trigger).
//   2. Sign in with correct credentials -> lands on ProfileScreen.
//   3. Sign in with wrong password -> user-safe error shown, no navigation.
//   4. Sign out -> redirected to SignInScreen, session cleared.
//   5. Kill and restart the app mid-session -> session restores without a
//      visible flash of the wrong screen (validates the router's loading
//      guard in core/router/app_router.dart).
//
// Do NOT implement this against production data or with fake data made to
// look like real user activity — use a disposable, clearly-labeled test
// Supabase project only, per the project's rule against fake production
// activity.

void main() {
  // Intentionally empty in VEYA 0.1. See file header.
}
