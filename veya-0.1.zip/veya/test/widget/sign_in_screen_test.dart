// VEYA 0.1 / 0.1-D — widget test
// STATUS: WRITTEN, NOT EXECUTED in this container (no Flutter SDK).
// Requires `flutter test` in a real SDK environment. Does not require a
// live Supabase project — Riverpod overrides replace the real
// authRepositoryProvider with a fake, so this is expected to run offline.

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:veya/core/error/failure.dart';
import 'package:veya/features/auth/application/auth_controller.dart';
import 'package:veya/features/auth/domain/app_user.dart';
import 'package:veya/features/auth/domain/auth_repository.dart';
import 'package:veya/features/auth/presentation/sign_in_screen.dart';

class _FakeAuthRepository implements AuthRepository {
  bool signInCalled = false;
  Failure? throwOnSignIn;
  AppUser? userAfterSignIn;

  @override
  Stream<AppUser?> authStateChanges() => const Stream.empty();

  @override
  AppUser? get currentUser => userAfterSignIn;

  @override
  Future<void> signIn({required String email, required String password}) async {
    signInCalled = true;
    if (throwOnSignIn != null) throw throwOnSignIn!;
  }

  @override
  Future<void> signUp({required String email, required String password}) async {}

  @override
  Future<void> signOut() async {}
}

void main() {
  testWidgets('shows a validation error when email is invalid', (tester) async {
    final fakeRepo = _FakeAuthRepository();

    await tester.pumpWidget(
      ProviderScope(
        overrides: [authRepositoryProvider.overrideWithValue(fakeRepo)],
        child: const MaterialApp(home: SignInScreen()),
      ),
    );

    await tester.enterText(find.byKey(const Key('signInEmailField')), 'not-an-email');
    await tester.enterText(find.byKey(const Key('signInPasswordField')), 'somepassword');
    await tester.tap(find.byKey(const Key('signInSubmitButton')));
    await tester.pump();

    expect(find.text('Enter a valid email'), findsOneWidget);
    expect(fakeRepo.signInCalled, isFalse);
  });

  testWidgets('calls signIn with trimmed email on valid submit', (tester) async {
    final fakeRepo = _FakeAuthRepository()
      ..userAfterSignIn = const AppUser(id: 'u1', email: 'user@example.com');

    await tester.pumpWidget(
      ProviderScope(
        overrides: [authRepositoryProvider.overrideWithValue(fakeRepo)],
        child: const MaterialApp(home: SignInScreen()),
      ),
    );

    await tester.enterText(find.byKey(const Key('signInEmailField')), ' user@example.com ');
    await tester.enterText(find.byKey(const Key('signInPasswordField')), 'somepassword');
    await tester.tap(find.byKey(const Key('signInSubmitButton')));
    await tester.pump();

    expect(fakeRepo.signInCalled, isTrue);
  });

  testWidgets('shows a user-safe message and re-enables the form on sign-in failure',
      (tester) async {
    final fakeRepo = _FakeAuthRepository()
      ..throwOnSignIn = const AuthFailure('Incorrect email or password.');

    await tester.pumpWidget(
      ProviderScope(
        overrides: [authRepositoryProvider.overrideWithValue(fakeRepo)],
        child: const MaterialApp(home: SignInScreen()),
      ),
    );

    await tester.enterText(find.byKey(const Key('signInEmailField')), 'user@example.com');
    await tester.enterText(find.byKey(const Key('signInPasswordField')), 'wrongpassword');
    await tester.tap(find.byKey(const Key('signInSubmitButton')));
    await tester.pump();

    expect(find.text('Incorrect email or password.'), findsOneWidget);
    // The submit button must be re-enabled after the error — the app must
    // never get stuck showing "Authenticating" forever on failure.
    final button = tester.widget<FilledButton>(find.byKey(const Key('signInSubmitButton')));
    expect(button.onPressed, isNotNull);
  });
}
