// VEYA 0.1-D — router / protected-route enforcement tests.
// STATUS: WRITTEN, NOT EXECUTED in this container (no Flutter SDK).
// Covers 0.1-D spec §19 Test 7 and Test 8, plus the startup-race and
// redirect-loop concerns in §12/§13. Uses fake Auth/Profile repositories —
// no live Supabase project needed to run this once a Flutter SDK is
// available.

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:go_router/go_router.dart';
import 'package:veya/core/router/app_router.dart';
import 'package:veya/features/auth/application/auth_controller.dart';
import 'package:veya/features/auth/domain/app_user.dart';
import 'package:veya/features/auth/domain/auth_repository.dart';
import 'package:veya/features/auth/presentation/sign_in_screen.dart';
import 'package:veya/features/profile/application/profile_controller.dart';
import 'package:veya/features/profile/domain/profile.dart';
import 'package:veya/features/profile/domain/profile_repository.dart';
import 'package:veya/features/profile/domain/profile_update.dart';
import 'package:veya/features/profile/presentation/profile_screen.dart';

import 'dart:async';

class _FakeAuthRepository implements AuthRepository {
  final _controller = StreamController<AppUser?>.broadcast();
  AppUser? _currentUser;

  void emit(AppUser? user) {
    _currentUser = user;
    _controller.add(user);
  }

  @override
  Stream<AppUser?> authStateChanges() => _controller.stream;

  @override
  AppUser? get currentUser => _currentUser;

  @override
  Future<void> signIn({required String email, required String password}) async {}

  @override
  Future<void> signUp({required String email, required String password}) async {}

  @override
  Future<void> signOut() async {
    _currentUser = null;
    _controller.add(null);
  }
}

class _FakeProfileRepository implements ProfileRepository {
  @override
  Future<Profile> getMyProfile() async => Profile(
        id: 'u1',
        username: 'real_username', // not a placeholder, so ProfileScreen (not
        // CompleteProfileScreen) is what a fully-onboarded authenticated
        // user should see.
        accountStatus: 'active',
        createdAt: DateTime.utc(2026, 1, 1),
      );

  @override
  Future<Profile> updateMyProfile(ProfileUpdate update) async => throw UnimplementedError();
}

void main() {
  testWidgets(
    'TEST 7: an unauthenticated user navigating directly to /profile is redirected '
    'to /sign-in, never shown protected content',
    (tester) async {
      final fakeAuth = _FakeAuthRepository();

      await tester.pumpWidget(
        ProviderScope(
          overrides: [
            authRepositoryProvider.overrideWithValue(fakeAuth),
            profileRepositoryProvider.overrideWithValue(_FakeProfileRepository()),
          ],
          child: Consumer(
            builder: (context, ref, _) => MaterialApp.router(
              routerConfig: ref.watch(routerProvider),
            ),
          ),
        ),
      );

      // Resolve the "unauthenticated" state (no session).
      fakeAuth.emit(null);
      await tester.pumpAndSettle();

      // Attempt direct navigation to a protected route.
      final router = GoRouter.of(tester.element(find.byType(MaterialApp)));
      router.go('/profile');
      await tester.pumpAndSettle();

      expect(find.byType(SignInScreen), findsOneWidget);
      expect(find.byType(ProfileScreen), findsNothing);
    },
  );

  testWidgets(
    'TEST 8: an authenticated user opening /profile directly is allowed through',
    (tester) async {
      final fakeAuth = _FakeAuthRepository();

      await tester.pumpWidget(
        ProviderScope(
          overrides: [
            authRepositoryProvider.overrideWithValue(fakeAuth),
            profileRepositoryProvider.overrideWithValue(_FakeProfileRepository()),
          ],
          child: Consumer(
            builder: (context, ref, _) => MaterialApp.router(
              routerConfig: ref.watch(routerProvider),
            ),
          ),
        ),
      );

      fakeAuth.emit(const AppUser(id: 'u1', email: 'user@example.com'));
      await tester.pumpAndSettle();

      final router = GoRouter.of(tester.element(find.byType(MaterialApp)));
      router.go('/profile');
      await tester.pumpAndSettle();

      expect(find.byType(ProfileScreen), findsOneWidget);
    },
  );

  testWidgets(
    'startup shows a splash (no redirect) while auth state is still Initializing, '
    'not a premature sign-in or protected screen',
    (tester) async {
      final fakeAuth = _FakeAuthRepository(); // never emits — stays Initializing

      await tester.pumpWidget(
        ProviderScope(
          overrides: [
            authRepositoryProvider.overrideWithValue(fakeAuth),
            profileRepositoryProvider.overrideWithValue(_FakeProfileRepository()),
          ],
          child: Consumer(
            builder: (context, ref, _) => MaterialApp.router(
              routerConfig: ref.watch(routerProvider),
            ),
          ),
        ),
      );
      await tester.pump();

      expect(find.byType(SignInScreen), findsNothing);
      expect(find.byType(ProfileScreen), findsNothing);
      expect(find.byType(CircularProgressIndicator), findsOneWidget);
    },
  );
}
