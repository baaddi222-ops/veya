// VEYA 0.1-E — widget tests for EditProfileScreen.
// STATUS: WRITTEN, NOT EXECUTED in this container (no Flutter SDK).
// Covers 0.1-E spec §21 Test 2, 8, 12 (the UI-level half of duplicate-
// submission prevention — see test/unit/profile_controller_test.dart for
// the controller-level half of that same boundary).

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:veya/features/profile/application/profile_controller.dart';
import 'package:veya/features/profile/domain/profile.dart';
import 'package:veya/features/profile/domain/profile_repository.dart';
import 'package:veya/features/profile/domain/profile_update.dart';
import 'package:veya/features/profile/presentation/edit_profile_screen.dart';

class _FakeProfileRepository implements ProfileRepository {
  _FakeProfileRepository(this._profile);

  Profile _profile;
  int updateCallCount = 0;

  @override
  Future<Profile> getMyProfile() async => _profile;

  @override
  Future<Profile> updateMyProfile(ProfileUpdate update) async {
    updateCallCount++;
    await Future<void>.delayed(const Duration(milliseconds: 50));
    _profile = _profile.copyWith(
      username: update.username,
      displayName: update.displayName,
      bio: update.bio,
    );
    return _profile;
  }
}

Profile _profile() => Profile(
      id: 'u1',
      username: 'real_username',
      displayName: 'Original Name',
      accountStatus: 'active',
      createdAt: DateTime.utc(2026, 1, 1),
    );

void main() {
  testWidgets('TEST 2: allowed field changes are saved via the repository', (tester) async {
    final fakeRepo = _FakeProfileRepository(_profile());

    await tester.pumpWidget(
      ProviderScope(
        overrides: [profileRepositoryProvider.overrideWithValue(fakeRepo)],
        child: MaterialApp(home: EditProfileScreen(profile: _profile())),
      ),
    );

    await tester.enterText(
      find.byKey(const Key('editProfileDisplayNameField')),
      'New Display Name',
    );
    await tester.tap(find.byKey(const Key('editProfileSaveButton')));
    await tester.pump(); // start the save
    await tester.pump(const Duration(milliseconds: 60)); // let it resolve

    expect(fakeRepo.updateCallCount, 1);
  });

  testWidgets('TEST 8: an over-length display name is rejected before the repository '
      'is ever called', (tester) async {
    final fakeRepo = _FakeProfileRepository(_profile());

    await tester.pumpWidget(
      ProviderScope(
        overrides: [profileRepositoryProvider.overrideWithValue(fakeRepo)],
        child: MaterialApp(home: EditProfileScreen(profile: _profile())),
      ),
    );

    await tester.enterText(
      find.byKey(const Key('editProfileDisplayNameField')),
      'a' * 51,
    );
    await tester.tap(find.byKey(const Key('editProfileSaveButton')));
    await tester.pump();

    expect(find.textContaining('50 characters or fewer'), findsOneWidget);
    expect(fakeRepo.updateCallCount, 0);
  });

  testWidgets(
    'TEST 12: tapping Save twice in quick succession only sends one update — the '
    'button is disabled while a save is already in flight',
    (tester) async {
      final fakeRepo = _FakeProfileRepository(_profile());

      await tester.pumpWidget(
        ProviderScope(
          overrides: [profileRepositoryProvider.overrideWithValue(fakeRepo)],
          child: MaterialApp(home: EditProfileScreen(profile: _profile())),
        ),
      );

      await tester.enterText(
        find.byKey(const Key('editProfileDisplayNameField')),
        'New Name',
      );

      // First tap starts the (slow, 50ms) save.
      await tester.tap(find.byKey(const Key('editProfileSaveButton')));
      await tester.pump(); // rebuild with isSaving == true, button now disabled

      // Second tap arrives while the first save is still in flight.
      await tester.tap(find.byKey(const Key('editProfileSaveButton')));
      await tester.pump(const Duration(milliseconds: 60)); // let the first save resolve

      expect(fakeRepo.updateCallCount, 1);
    },
  );
}
