// VEYA 0.1 — widget test
// STATUS: WRITTEN, NOT EXECUTED in this container (no Flutter SDK).
// Requires `flutter test` in a real SDK environment. Uses a fake
// ProfileRepository via Riverpod override — no live Supabase project needed
// to run this once a Flutter SDK is available.

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:veya/core/error/failure.dart';
import 'package:veya/features/profile/application/profile_controller.dart';
import 'package:veya/features/profile/domain/profile.dart';
import 'package:veya/features/profile/domain/profile_repository.dart';
import 'package:veya/features/profile/domain/profile_update.dart';
import 'package:veya/features/profile/presentation/complete_profile_screen.dart';

class _FakeProfileRepository implements ProfileRepository {
  _FakeProfileRepository(this._profile);

  Profile _profile;
  bool updateCalled = false;
  bool throwDuplicateOnNextUpdate = false;

  @override
  Future<Profile> getMyProfile() async => _profile;

  @override
  Future<Profile> updateMyProfile(ProfileUpdate update) async {
    updateCalled = true;
    if (throwDuplicateOnNextUpdate) {
      throw const ValidationFailure('That username is already taken.');
    }
    _profile = _profile.copyWith(username: update.username);
    return _profile;
  }
}

Profile _placeholderProfile() => Profile(
      id: 'u1',
      username: 'user_8c425d1b', // matches the trigger's placeholder format
      accountStatus: 'active',
      createdAt: DateTime.utc(2026, 1, 1),
    );

void main() {
  testWidgets('rejects a too-short username before calling the repository', (tester) async {
    final fakeRepo = _FakeProfileRepository(_placeholderProfile());

    await tester.pumpWidget(
      ProviderScope(
        overrides: [profileRepositoryProvider.overrideWithValue(fakeRepo)],
        child: const MaterialApp(home: CompleteProfileScreen()),
      ),
    );
    await tester.pump();

    await tester.enterText(find.byKey(const Key('completeProfileUsernameField')), 'ab');
    await tester.tap(find.byKey(const Key('completeProfileSubmitButton')));
    await tester.pump();

    expect(find.textContaining('3-24 characters'), findsOneWidget);
    expect(fakeRepo.updateCalled, isFalse);
  });

  testWidgets('submits a valid username to the repository', (tester) async {
    final fakeRepo = _FakeProfileRepository(_placeholderProfile());

    await tester.pumpWidget(
      ProviderScope(
        overrides: [profileRepositoryProvider.overrideWithValue(fakeRepo)],
        child: const MaterialApp(home: CompleteProfileScreen()),
      ),
    );
    await tester.pump();

    await tester.enterText(find.byKey(const Key('completeProfileUsernameField')), 'real_username');
    await tester.tap(find.byKey(const Key('completeProfileSubmitButton')));
    await tester.pump();

    expect(fakeRepo.updateCalled, isTrue);
  });

  testWidgets('shows a user-safe message on duplicate username', (tester) async {
    final fakeRepo = _FakeProfileRepository(_placeholderProfile())
      ..throwDuplicateOnNextUpdate = true;

    await tester.pumpWidget(
      ProviderScope(
        overrides: [profileRepositoryProvider.overrideWithValue(fakeRepo)],
        child: const MaterialApp(home: CompleteProfileScreen()),
      ),
    );
    await tester.pump();

    await tester.enterText(find.byKey(const Key('completeProfileUsernameField')), 'taken_name');
    await tester.tap(find.byKey(const Key('completeProfileSubmitButton')));
    await tester.pump();

    expect(find.text('That username is already taken.'), findsOneWidget);
  });
}
