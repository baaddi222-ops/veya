// VEYA 0.1-E — unit tests for the typed ProfileUpdate model.
// STATUS: WRITTEN, NOT EXECUTED in this container (no Flutter SDK). Pure
// Dart, no Supabase/Flutter dependency. Covers 0.1-E spec §21 Test 3.

import 'package:flutter_test/flutter_test.dart';
import 'package:veya/features/profile/domain/profile_update.dart';

void main() {
  test('TEST 3: ProfileUpdate has no way to express protected fields — this '
      'compiles at all only because id/createdAt/updatedAt/accountStatus have '
      'no corresponding named parameters. That is the test: the attempt below '
      'is exactly what the type system makes impossible, demonstrated by what '
      'IS expressible instead.', () {
    // The following would be a compile error if uncommented, which is
    // exactly the point — there is no `id:`, `createdAt:`, `updatedAt:`, or
    // `accountStatus:` parameter to pass:
    //   ProfileUpdate(id: 'other-user-id');
    //   ProfileUpdate(accountStatus: 'suspended');
    //   ProfileUpdate(createdAt: DateTime(2000));
    const update = ProfileUpdate(username: 'safe_username', bio: 'hello');
    expect(update.username, 'safe_username');
    expect(update.bio, 'hello');
  });

  test('toColumnMap includes only fields that were actually set', () {
    const update = ProfileUpdate(displayName: 'Ali');
    final map = update.toColumnMap();
    expect(map, {'display_name': 'Ali'});
    expect(map.containsKey('username'), isFalse);
    expect(map.containsKey('avatar_url'), isFalse);
    expect(map.containsKey('bio'), isFalse);
  });

  test('toColumnMap uses correct database column names, not Dart field names', () {
    const update = ProfileUpdate(displayName: 'Ali', avatarUrl: 'https://example.com/a.png');
    final map = update.toColumnMap();
    expect(map['display_name'], 'Ali');
    expect(map['avatar_url'], 'https://example.com/a.png');
  });

  test('isEmpty is true only when every field is null', () {
    expect(const ProfileUpdate().isEmpty, isTrue);
    expect(const ProfileUpdate(bio: 'x').isEmpty, isFalse);
  });
}
