// VEYA 0.1 — unit test
// STATUS: WRITTEN, NOT EXECUTED in this container (no Flutter/Dart SDK,
// no network to fetch packages — see final report). This test does not
// depend on Supabase or Flutter widgets, only on core/error/failure.dart,
// so it is expected to run with a plain `dart test` or `flutter test` once
// a real SDK environment is available.

import 'package:flutter_test/flutter_test.dart';
import 'package:veya/core/error/failure.dart';

void main() {
  group('Failure types', () {
    test('AuthFailure carries a user-safe message and optional code', () {
      const failure = AuthFailure('Incorrect email or password.', code: 'invalid_credentials');

      expect(failure.message, 'Incorrect email or password.');
      expect(failure.code, 'invalid_credentials');
      expect(failure, isA<Failure>());
    });

    test('NetworkFailure has a sensible default message', () {
      const failure = NetworkFailure();
      expect(failure.message, isNotEmpty);
    });

    test('ValidationFailure preserves the given message verbatim', () {
      const failure = ValidationFailure('That username is already taken.');
      expect(failure.message, 'That username is already taken.');
    });

    test('UnknownFailure never exposes empty message', () {
      const failure = UnknownFailure();
      expect(failure.message, isNotEmpty);
    });
  });
}
