// VEYA 0.1 — unit test
// STATUS: WRITTEN, NOT EXECUTED in this container. Pure-Dart domain test,
// no Supabase/Flutter dependency — expected to run under `flutter test`
// once an SDK environment is available.

import 'package:flutter_test/flutter_test.dart';
import 'package:veya/features/profile/domain/profile.dart';

void main() {
  test('Profile.copyWith updates only the given fields', () {
    final original = Profile(
      id: 'u1',
      username: 'user_abc123',
      displayName: null,
      avatarUrl: null,
      bio: null,
      accountStatus: 'active',
      createdAt: DateTime.utc(2026, 1, 1),
    );

    final updated = original.copyWith(displayName: 'Ali');

    expect(updated.username, original.username);
    expect(updated.displayName, 'Ali');
    expect(updated.id, original.id);
    expect(updated.createdAt, original.createdAt);
  });

  group('Profile.hasPlaceholderUsername', () {
    test('is true for a trigger-generated placeholder username', () {
      final profile = Profile(
        id: 'u1',
        username: 'user_8c425d1b', // matches migration 0003's format exactly
        accountStatus: 'active',
        createdAt: DateTime.utc(2026, 1, 1),
      );
      expect(profile.hasPlaceholderUsername, isTrue);
    });

    test('is false for a real chosen username', () {
      final profile = Profile(
        id: 'u1',
        username: 'real_username',
        accountStatus: 'active',
        createdAt: DateTime.utc(2026, 1, 1),
      );
      expect(profile.hasPlaceholderUsername, isFalse);
    });

    test('is false for a username that merely starts with user_ but is longer', () {
      final profile = Profile(
        id: 'u1',
        username: 'user_this_is_not_a_placeholder',
        accountStatus: 'active',
        createdAt: DateTime.utc(2026, 1, 1),
      );
      expect(profile.hasPlaceholderUsername, isFalse);
    });
  });
}
