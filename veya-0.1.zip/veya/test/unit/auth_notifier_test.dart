// VEYA 0.1-D — unit tests for the unified AuthState/AuthNotifier state
// machine.
// STATUS: WRITTEN, NOT EXECUTED in this container (no Flutter SDK). Pure
// Dart + Riverpod core (no widget tree needed) — expected to run under
// `flutter test` (or `dart test` with the riverpod package) once an SDK
// environment is available. Covers 0.1-D spec §19 Test 1, 2, 3, 4, 5, 6,
// 9, 12.

import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:veya/core/error/failure.dart';
import 'package:veya/features/auth/application/auth_controller.dart';
import 'package:veya/features/auth/domain/app_user.dart';
import 'package:veya/features/auth/domain/auth_repository.dart';

class _FakeAuthRepository implements AuthRepository {
  final _controller = StreamController<AppUser?>.broadcast();
  AppUser? _currentUser;
  Failure? throwOnSignIn;
  Failure? throwOnSignOut;

  void emit(AppUser? user) {
    _currentUser = user;
    _controller.add(user);
  }

  void emitError(Object error) => _controller.addError(error);

  bool get hasListener => _controller.hasListener;

  @override
  Stream<AppUser?> authStateChanges() => _controller.stream;

  @override
  AppUser? get currentUser => _currentUser;

  @override
  Future<void> signIn({required String email, required String password}) async {
    if (throwOnSignIn != null) throw throwOnSignIn!;
    _currentUser = const AppUser(id: 'u1', email: 'user@example.com');
  }

  @override
  Future<void> signUp({required String email, required String password}) async {
    if (throwOnSignIn != null) throw throwOnSignIn!;
    _currentUser = const AppUser(id: 'u1', email: 'user@example.com');
  }

  @override
  Future<void> signOut() async {
    if (throwOnSignOut != null) throw throwOnSignOut!;
    _currentUser = null;
  }
}

void main() {
  late _FakeAuthRepository fakeRepo;
  late ProviderContainer container;

  setUp(() {
    fakeRepo = _FakeAuthRepository();
    container = ProviderContainer(
      overrides: [authRepositoryProvider.overrideWithValue(fakeRepo)],
    );
  });

  tearDown(() => container.dispose());

  test('TEST 1: starts as AuthInitializing before the stream emits', () {
    expect(container.read(authProvider), isA<AuthInitializing>());
  });

  test('TEST 1/2: an empty stream (no session) resolves to AuthUnauthenticated', () {
    container.read(authProvider); // trigger build()
    fakeRepo.emit(null);
    expect(container.read(authProvider), isA<AuthUnauthenticated>());
  });

  test('TEST 2: an existing valid session resolves to AuthAuthenticated', () {
    container.read(authProvider);
    const user = AppUser(id: 'u1', email: 'user@example.com');
    fakeRepo.emit(user);
    final state = container.read(authProvider);
    expect(state, isA<AuthAuthenticated>());
    expect((state as AuthAuthenticated).user.id, 'u1');
  });

  test('TEST 4: signed out -> signed in transitions to AuthAuthenticated', () {
    container.read(authProvider);
    fakeRepo.emit(null);
    expect(container.read(authProvider), isA<AuthUnauthenticated>());

    const user = AppUser(id: 'u2', email: 'two@example.com');
    fakeRepo.emit(user);
    expect(container.read(authProvider), isA<AuthAuthenticated>());
  });

  test('TEST 5: signed in -> signed out removes authenticated state', () {
    container.read(authProvider);
    const user = AppUser(id: 'u1', email: 'user@example.com');
    fakeRepo.emit(user);
    expect(container.read(authProvider), isA<AuthAuthenticated>());

    fakeRepo.emit(null);
    expect(container.read(authProvider), isA<AuthUnauthenticated>());
  });

  test('TEST 6: a stream error is treated as unauthenticated, never authenticated '
      '(fail closed)', () {
    container.read(authProvider);
    const user = AppUser(id: 'u1', email: 'user@example.com');
    fakeRepo.emit(user);
    expect(container.read(authProvider), isA<AuthAuthenticated>());

    fakeRepo.emitError(Exception('simulated network drop'));
    expect(container.read(authProvider), isA<AuthUnauthenticated>());
  });

  test('sign-in sets AuthAuthenticating immediately, then AuthAuthenticated on success',
      () async {
    container.read(authProvider);
    final future = container.read(authProvider.notifier).signIn(
          email: 'user@example.com',
          password: 'password123',
        );
    expect(container.read(authProvider), isA<AuthAuthenticating>());
    await future;
    expect(container.read(authProvider), isA<AuthAuthenticated>());
  });

  test('sign-in failure resolves to AuthenticationError carrying the Failure', () async {
    fakeRepo.throwOnSignIn = const AuthFailure('Incorrect email or password.');
    container.read(authProvider);
    await container.read(authProvider.notifier).signIn(
          email: 'user@example.com',
          password: 'wrong',
        );
    final state = container.read(authProvider);
    expect(state, isA<AuthenticationError>());
    expect((state as AuthenticationError).failure.message, 'Incorrect email or password.');
  });

  test('TEST 3: sign-out sets AuthSigningOut immediately, then AuthUnauthenticated', () async {
    container.read(authProvider);
    fakeRepo.emit(const AppUser(id: 'u1', email: 'user@example.com'));
    expect(container.read(authProvider), isA<AuthAuthenticated>());

    final future = container.read(authProvider.notifier).signOut();
    expect(container.read(authProvider), isA<AuthSigningOut>());
    await future;
    expect(container.read(authProvider), isA<AuthUnauthenticated>());
  });

  test('sign-out forces AuthUnauthenticated even if the remote call fails '
      '(never leaves stale authenticated state)', () async {
    fakeRepo.throwOnSignOut = const AuthFailure('network blip');
    container.read(authProvider);
    fakeRepo.emit(const AppUser(id: 'u1', email: 'user@example.com'));

    await container.read(authProvider.notifier).signOut();
    expect(container.read(authProvider), isA<AuthUnauthenticated>());
  });

  test('TEST 9: AuthRepository interface accepts no ownership id — identity comes only '
      'from the session (compile-time contract, exercised here at the call sites)', () async {
    // signIn/signUp/signOut take no user-id parameter at all; currentUser
    // and authStateChanges() are the only ways identity is ever read, and
    // both come from the repository's own session state, never from a
    // caller-supplied value. This test exercises every call site with no
    // id argument available to pass, which is what the interface enforces
    // at compile time.
    container.read(authProvider);
    await container.read(authProvider.notifier).signIn(email: 'a@example.com', password: 'x');
    await container.read(authProvider.notifier).signOut();
    await container.read(authProvider.notifier).signUp(email: 'b@example.com', password: 'y');
    // Reaching here without a compile error already demonstrates the
    // contract; the assertion below just confirms behavior stayed sane.
    expect(fakeRepo.currentUser?.id, isNot('arbitrary-injected-id'));
  });

  test('TEST 12: exactly one listener on the underlying auth stream, and it is '
      'removed on dispose (no duplicate/leaked subscriptions)', () {
    container.read(authProvider); // triggers AuthNotifier.build(), which subscribes
    expect(fakeRepo.hasListener, isTrue);

    container.dispose();
    expect(fakeRepo.hasListener, isFalse);
  });
}
