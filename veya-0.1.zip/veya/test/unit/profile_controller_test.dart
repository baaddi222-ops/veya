// VEYA 0.1-E — unit tests for MyProfileController and the
// ProfileRepository ownership contract.
// STATUS: WRITTEN, NOT EXECUTED in this container (no Flutter SDK). Pure
// Dart + Riverpod core (no widget tree needed). Covers 0.1-E spec §21
// Test 1, 5, 11, 12.

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:veya/core/error/failure.dart';
import 'package:veya/features/profile/application/profile_controller.dart';
import 'package:veya/features/profile/domain/profile.dart';
import 'package:veya/features/profile/domain/profile_repository.dart';
import 'package:veya/features/profile/domain/profile_update.dart';

class _FakeProfileRepository implements ProfileRepository {
  _FakeProfileRepository(this._profile);

  Profile _profile;
  Failure? throwOnGet;
  int getCallCount = 0;
  int updateCallCount = 0;

  @override
  Future<Profile> getMyProfile() async {
    getCallCount++;
    if (throwOnGet != null) throw throwOnGet!;
    return _profile;
  }

  @override
  Future<Profile> updateMyProfile(ProfileUpdate update) async {
    updateCallCount++;
    // Deliberately slow, to make a duplicate-submission race observable in
    // TEST 12 below.
    await Future<void>.delayed(const Duration(milliseconds: 10));
    _profile = _profile.copyWith(
      username: update.username,
      displayName: update.displayName,
      bio: update.bio,
    );
    return _profile;
  }
}

Profile _profile() => Profile(
      id: 'u1',
      username: 'real_username',
      accountStatus: 'active',
      createdAt: DateTime.utc(2026, 1, 1),
    );

void main() {
  test('TEST 1: authenticated user retrieves own profile via the controller', () async {
    final fakeRepo = _FakeProfileRepository(_profile());
    final container = ProviderContainer(
      overrides: [profileRepositoryProvider.overrideWithValue(fakeRepo)],
    );
    addTearDown(container.dispose);

    final profile = await container.read(myProfileProvider.future);
    expect(profile.username, 'real_username');
    expect(fakeRepo.getCallCount, 1);
  });

  test('TEST 11: a repository failure while loading is surfaced as an AsyncError '
      'carrying the mapped Failure, not a raw exception', () async {
    final fakeRepo = _FakeProfileRepository(_profile())
      ..throwOnGet = const UnknownFailure('Could not load your profile.');
    final container = ProviderContainer(
      overrides: [profileRepositoryProvider.overrideWithValue(fakeRepo)],
    );
    addTearDown(container.dispose);

    // Reading .future should rethrow; catch and inspect.
    await expectLater(
      container.read(myProfileProvider.future),
      throwsA(isA<UnknownFailure>()),
    );
    expect(container.read(myProfileProvider).hasError, isTrue);
    expect(container.read(myProfileProvider).error, isA<Failure>());
  });

  test('TEST 5 (repository ownership contract): ProfileRepository has no method '
      'that accepts another user\'s id — getMyProfile() and updateMyProfile() take '
      'no id parameter at all, so there is no arbitrary-ID path to express, '
      'enforced by the interface at compile time', () async {
    final fakeRepo = _FakeProfileRepository(_profile());
    final container = ProviderContainer(
      overrides: [profileRepositoryProvider.overrideWithValue(fakeRepo)],
    );
    addTearDown(container.dispose);

    // There is no container.read(myProfileProvider.notifier).update(someOtherUsersId, ...)
    // possible to even write — update() only accepts a ProfileUpdate, which
    // itself has no id/ownership field (see profile_update_test.dart TEST 3).
    await container.read(myProfileProvider.future);
    await container.read(myProfileProvider.notifier).update(const ProfileUpdate(bio: 'x'));
    expect(container.read(myProfileProvider).value?.bio, 'x');
  });

  test('TEST 12: two near-simultaneous update() calls both reach the repository '
      '(de-duplication is a UI-layer responsibility — disabling the save button — '
      'not the controller\'s; this test documents that boundary rather than '
      'asserting the controller itself de-dupes, which it deliberately does not)',
      () async {
    final fakeRepo = _FakeProfileRepository(_profile());
    final container = ProviderContainer(
      overrides: [profileRepositoryProvider.overrideWithValue(fakeRepo)],
    );
    addTearDown(container.dispose);
    await container.read(myProfileProvider.future);

    final notifier = container.read(myProfileProvider.notifier);
    final first = notifier.update(const ProfileUpdate(bio: 'first'));
    final second = notifier.update(const ProfileUpdate(bio: 'second'));
    await Future.wait([first, second]);

    // Both calls reached the repository — this is expected and fine at the
    // controller level; EditProfileScreen/CompleteProfileScreen are what
    // actually prevent this in practice by disabling the button while
    // `state.isLoading` is true (see their widget tests).
    expect(fakeRepo.updateCallCount, 2);
  });
}
