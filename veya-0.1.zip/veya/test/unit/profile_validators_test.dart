// VEYA 0.1-E — unit tests for shared ProfileValidators.
// STATUS: WRITTEN, NOT EXECUTED in this container (no Flutter SDK). Pure
// Dart, no Supabase/Flutter dependency. Covers 0.1-E spec §21 Test 8, 9.
// These mirror (not replace) the database CHECK constraints (migrations
// 0001, 0007), which remain the authoritative boundary — see
// supabase/tests/rls_security_tests.sql TEST 14 for the live-executed
// database-level equivalents of the username cases here.

import 'package:flutter_test/flutter_test.dart';
import 'package:veya/features/profile/domain/profile_validators.dart';

void main() {
  group('ProfileValidators.username', () {
    test('valid username is accepted', () {
      expect(ProfileValidators.username('valid_username_1'), isNull);
    });

    test('empty username is rejected', () {
      expect(ProfileValidators.username(''), isNotNull);
    });

    test('too-short username is rejected', () {
      expect(ProfileValidators.username('ab'), isNotNull);
    });

    test('too-long (25 char) username is rejected', () {
      expect(ProfileValidators.username('a' * 25), isNotNull);
    });

    test('exactly-24-char username is accepted (boundary)', () {
      expect(ProfileValidators.username('a' * 24), isNull);
    });

    test('uppercase is rejected (must match DB format constraint)', () {
      expect(ProfileValidators.username('UPPERCASE1'), isNotNull);
    });

    test('SQL-injection-shaped input is rejected by the format rule', () {
      expect(ProfileValidators.username("robert'); drop table profiles;--"), isNotNull);
    });

    test('unicode username is rejected (DB format constraint is ASCII-only)', () {
      expect(ProfileValidators.username('محمد123'), isNotNull);
    });
  });

  group('ProfileValidators.displayName', () {
    test('null/empty is valid (optional field)', () {
      expect(ProfileValidators.displayName(null), isNull);
      expect(ProfileValidators.displayName(''), isNull);
    });

    test('a name at the 50-char boundary is accepted', () {
      expect(ProfileValidators.displayName('a' * 50), isNull);
    });

    test('a 51-char name is rejected', () {
      expect(ProfileValidators.displayName('a' * 51), isNotNull);
    });

    test('unicode display name well under the limit is accepted', () {
      expect(ProfileValidators.displayName('محمد الأمين 😀 José Müller'), isNull);
    });
  });

  group('ProfileValidators.bio', () {
    test('null/empty is valid (optional field)', () {
      expect(ProfileValidators.bio(null), isNull);
    });

    test('a bio at the 280-char boundary is accepted', () {
      expect(ProfileValidators.bio('a' * 280), isNull);
    });

    test('a 281-char bio is rejected', () {
      expect(ProfileValidators.bio('a' * 281), isNotNull);
    });
  });
}
