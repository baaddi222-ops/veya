// VEYA 0.1-D (follow-up) — unit test for SecureSessionStorage.
// STATUS: WRITTEN, NOT EXECUTED in this container (no Flutter SDK). Mocks
// the flutter_secure_storage platform channel directly rather than hitting
// real OS keychain/keystore, so this is expected to run under `flutter
// test` without a device/simulator once an SDK environment is available.
// The exact mocked channel name/method shape may need a small adjustment
// against whatever flutter_secure_storage version actually resolves at
// `flutter pub get` time — noted here rather than left silent, since it
// could not be executed to confirm precisely.

import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:veya/core/config/secure_session_storage.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  const channel = MethodChannel('plugins.it_nomads.com/flutter_secure_storage');
  final store = <String, String>{};

  setUp(() {
    store.clear();
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(channel, (call) async {
      switch (call.method) {
        case 'write':
          store[call.arguments['key'] as String] = call.arguments['value'] as String;
          return null;
        case 'read':
          return store[call.arguments['key'] as String];
        case 'containsKey':
          return store.containsKey(call.arguments['key'] as String);
        case 'delete':
          store.remove(call.arguments['key'] as String);
          return null;
        default:
          return null;
      }
    });
  });

  tearDown(() {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(channel, null);
  });

  test('persistSession then accessToken round-trips the same value', () async {
    final storage = SecureSessionStorage();
    await storage.persistSession('fake-session-json');
    expect(await storage.hasAccessToken(), isTrue);
    expect(await storage.accessToken(), 'fake-session-json');
  });

  test('removePersistedSession clears the stored value', () async {
    final storage = SecureSessionStorage();
    await storage.persistSession('fake-session-json');
    await storage.removePersistedSession();
    expect(await storage.hasAccessToken(), isFalse);
    expect(await storage.accessToken(), isNull);
  });

  test('hasAccessToken is false before any session is persisted', () async {
    final storage = SecureSessionStorage();
    expect(await storage.hasAccessToken(), isFalse);
  });
}
